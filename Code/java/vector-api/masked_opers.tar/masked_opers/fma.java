
import jdk.incubator.vector.*;

class fma {

  public static VectorSpecies<Float> SPECIES = FloatVector.SPECIES_256;

  public static void workload(float[] arr1, float[] arr2, float[] arr3, float[] res) {
    boolean [] mask_arr = {true, true, true, true, false, false, false, false};
    VectorMask<Float> mask = VectorMask.fromArray(SPECIES, mask_arr, 0);
    FloatVector vec1 = FloatVector.fromArray(SPECIES, arr1, 0);
    FloatVector vec2 = FloatVector.fromArray(SPECIES, arr2, 0);
    FloatVector vec3 = FloatVector.fromArray(SPECIES, arr3, 0);
    vec1.lanewise(VectorOperators.FMA, vec2, vec3, mask).intoArray(res,0);
  }

  public static void main(String [] args) {
    float [] arr1 = new float[8];
    float [] arr2 = new float[8];
    float [] arr3 = new float[8];
    float [] res  = new float[8];
    for (int i = 0 ; i < arr1.length ; i++) {
       arr1[i] = i*1.0f;
       arr2[i] = i*1.0f;
       arr3[i] = i*1.0f;
    }

    // Warmup
    for (int i = 0 ; i < 700000 ; i++)
      workload(arr1, arr2, arr3, res);

    // Perf
    long start = System.currentTimeMillis();
    for (int i = 0 ; i < 100000 ; i++)
      workload(arr1, arr2, arr3, res);
    long time = System.currentTimeMillis() - start;
    System.out.println("Time = " + time);

    for (var elem : res) {
      System.out.println(elem + " ");
    }
  }
}
