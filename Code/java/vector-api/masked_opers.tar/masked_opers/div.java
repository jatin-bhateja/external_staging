
import jdk.incubator.vector.*;

class div {
  public static VectorSpecies<Float> SPECIES = FloatVector.SPECIES_256;
  public static void workload(float [] arr, float [] res) {
      boolean [] mask_arr = {true, true, true, true, false, false, false, false};
      VectorMask<Float> mask = VectorMask.fromArray(SPECIES, mask_arr, 0);
      FloatVector vecv = FloatVector.fromArray(SPECIES, arr, 0);
      FloatVector resv = FloatVector.fromArray(SPECIES, arr, 0);
      resv.lanewise(VectorOperators.DIV, vecv, mask).intoArray(res,0);
  }

  public static void main(String [] args) {
     float [] arr = new float[8];
     float [] res = new float[8];
     for (int i = 0 ; i < arr.length ; i++) {
       arr[i] = (float)i+1;
       res[i] = (float)i+1;
     }

     // Warmup
     for (int i = 0 ; i < 700000 ; i++)
       workload(arr, res);

     // Perf
     long start = System.currentTimeMillis();
     for (int i = 0 ; i < 100000 ; i++)
       workload(arr, res);

     long time = System.currentTimeMillis() - start;
     System.out.println("Time = " + time);

     for (var elem : res) {
       System.out.println(elem + " ");
     }
  }
}
