
public interface VectorSpecies<E> {
}
