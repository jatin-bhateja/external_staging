
public abstract class Vector<E> extends VectorSupport.Vector<E> {
}
