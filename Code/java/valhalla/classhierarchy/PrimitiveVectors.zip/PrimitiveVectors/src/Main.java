public class Main {
    public static void main(String[] args) {
        IntVector.getVector(IntVector.SPECIES_256);
    }
}
