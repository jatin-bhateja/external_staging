
#################################################################################################################
## Encoder-Decoder RNNs:
##
## Architecture: Encoder-decoder RNNs consist of two separate RNNs: an encoder and a decoder. The encoder
## processes the input sequence and generates a fixed-length representation (context vector or latent space) 
## capturing the input sequence's information. The decoder then takes this representation and generates the
## output sequence.
##
## Training Strategy: During training, the input sequence is fed into the encoder, and the ground truth 
## output sequence is fed into the decoder. The context vector from the encoder is used to initialize the
## hidden state of the decoder. The decoder is trained to generate the correct output sequence given the
## context vector and the ground truth outputs.
##
## Inference: During inference, the input sequence is fed into the encoder to generate the context vector.
## The decoder then generates the output sequence autoregressively based on its own predictions from previous 
## time steps, similar to RNNs with teacher forcing.
##
#################################################################################################################

import os
import re
import glob
import shutil
import unicodedata
import numpy as np
import tensorflow as tf

def clean_up_logs(data_dir):
    checkpoint_dir = os.path.join(data_dir, "checkpoints")
    if os.path.exists(checkpoint_dir):
        shutil.rmtree(checkpoint_dir, ignore_errors=True)
        os.makedirs(checkpoint_dir)
    return checkpoint_dir

def preprocess_sentence(sent):
    sent = "".join([c for c in unicodedata.normalize("NFD", sent) 
        if unicodedata.category(c) != "Mn"])
    sent = re.sub(r'//.*|/\*(.|\n)*?\*/', '', sent)
    return sent


def read_sources():
    cpp_s_lines, java_s_lines_in, java_s_lines_out = [], [], []
    cpp_s = glob.glob('*.cpp')
    java_s = glob.glob('*.java')
    for cpp in cpp_s:
        with open(cpp, "r") as fin:
            for i, line in enumerate(fin):
                cpp_s_line = line.strip() 
                cpp_s_line = preprocess_sentence(cpp_s_line)
                if cpp_s_line == '':
                    continue
                cpp_s_line = [w for w in cpp_s_line.split()]
                cpp_s_lines.append(cpp_s_line)
        print("Processed Input CPP : " + cpp)
    for java in java_s:
        with open(java, "r") as fin:
            for i, line in enumerate(fin):
                java_s_line = line.strip() 
                java_s_line = preprocess_sentence(java_s_line)
                if java_s_line == '':
                    continue
                java_s_line_in = [w for w in ("BOS " + java_s_line).split()]
                java_s_line_out = [w for w in (java_s_line + " EOS").split()]
                java_s_lines_in.append(java_s_line_in)
                java_s_lines_out.append(java_s_line_out)
        print("Processed Output Java : " + java)
    return cpp_s_lines, java_s_lines_in, java_s_lines_out


class Encoder(tf.keras.Model):
    def __init__(self, vocab_size, embedding_dim, num_timesteps, 
            encoder_dim, **kwargs):
        super(Encoder, self).__init__(**kwargs)
        self.encoder_dim = encoder_dim
        self.embedding = tf.keras.layers.Embedding(
            vocab_size, embedding_dim, input_length=num_timesteps)
        self.rnn = tf.keras.layers.GRU(
            encoder_dim, return_sequences=False, return_state=True)

    def call(self, x, state):
        x = self.embedding(x)
        x, state = self.rnn(x, initial_state=state)
        return x, state

    def init_state(self, batch_size):
        return tf.zeros((batch_size, self.encoder_dim))


class Decoder(tf.keras.Model):
    def __init__(self, vocab_size, embedding_dim, num_timesteps,
            decoder_dim, **kwargs):
        super(Decoder, self).__init__(**kwargs)
        self.decoder_dim = decoder_dim
        self.embedding = tf.keras.layers.Embedding(
            vocab_size, embedding_dim, input_length=num_timesteps)
        self.rnn = tf.keras.layers.GRU(
            decoder_dim, return_sequences=True, return_state=True)
        self.dense = tf.keras.layers.Dense(vocab_size)

    def call(self, x, state):
        x = self.embedding(x)
        x, state = self.rnn(x, state)
        x = self.dense(x)
        return x, state


def loss_fn(ytrue, ypred):
    scce = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
    mask = tf.math.logical_not(tf.math.equal(ytrue, 0))
    mask = tf.cast(mask, dtype=tf.int64)
    loss = scce(ytrue, ypred, sample_weight=mask)
    return loss


@tf.function
def train_step(encoder_in, decoder_in, decoder_out, encoder_state):
    with tf.GradientTape() as tape:
        encoder_out, encoder_state = encoder(encoder_in, encoder_state)
        decoder_state = encoder_state
        decoder_pred, decoder_state = decoder(decoder_in, decoder_state)
        loss = loss_fn(decoder_out, decoder_pred)
    
    variables = encoder.trainable_variables + decoder.trainable_variables
    gradients = tape.gradient(loss, variables)
    optimizer.apply_gradients(zip(gradients, variables))
    return loss


def predict(encoder, decoder, batch_size, 
        cpp_code_line, data_cpp, java_code_line_out, 
        word2idx_java, idx2word_java, min_samples):
    random_id = np.random.choice(min_samples)
    print("input    : ",  " ".join(cpp_code_line[random_id]))
    print("label    : ", " ".join(java_code_line_out[random_id]))

    encoder_in = tf.expand_dims(data_cpp[random_id], axis=0)
    decoder_out = tf.expand_dims(java_code_line_out[random_id], axis=0)

    encoder_state = encoder.init_state(1)
    encoder_out, encoder_state = encoder(encoder_in, encoder_state)
    decoder_state = encoder_state

    decoder_in = tf.expand_dims(
        tf.constant([word2idx_java["BOS"]]), axis=0)
    pred_sent_java = []
    while True:
        decoder_pred, decoder_state = decoder(decoder_in, decoder_state)
        decoder_pred = tf.argmax(decoder_pred, axis=-1)
        pred_word = idx2word_java[decoder_pred.numpy()[0][0]]
        pred_sent_java.append(pred_word)
        if pred_word == "EOS":
            break
        decoder_in = decoder_pred
    
    print("predicted: ", " ".join(pred_sent_java))


EMBEDDING_DIM = 256
ENCODER_DIM, DECODER_DIM = 1024, 1024
BATCH_SIZE = 64
NUM_EPOCHS = 30

tf.random.set_seed(42)

data_dir = "./data"
checkpoint_dir = clean_up_logs(data_dir)

cpp_code_line, java_code_line_in, java_code_line_out = read_sources()

tokenizer_cpp = tf.keras.preprocessing.text.Tokenizer(
    filters="", lower=False)
tokenizer_cpp.fit_on_texts(cpp_code_line)
data_cpp = tokenizer_cpp.texts_to_sequences(cpp_code_line)
data_cpp = tf.keras.preprocessing.sequence.pad_sequences(data_cpp, padding="post")

tokenizer_java = tf.keras.preprocessing.text.Tokenizer(
    filters="", lower=False)
tokenizer_java.fit_on_texts(java_code_line_in)
tokenizer_java.fit_on_texts(java_code_line_out)
data_java_in = tokenizer_java.texts_to_sequences(java_code_line_in)
data_java_in = tf.keras.preprocessing.sequence.pad_sequences(data_java_in, padding="post")
data_java_out = tokenizer_java.texts_to_sequences(java_code_line_out)
data_java_out = tf.keras.preprocessing.sequence.pad_sequences(data_java_out, padding="post")

vocab_size_cpp = len(tokenizer_cpp.word_index)
vocab_size_java = len(tokenizer_java.word_index)
word2idx_cpp = tokenizer_cpp.word_index
idx2word_cpp = {v:k for k, v in word2idx_cpp.items()}
word2idx_java = tokenizer_java.word_index
idx2word_java = {v:k for k, v in word2idx_java.items()}
print("vocab size (cpp): {:d}, vocab size (java): {:d}".format(
    vocab_size_cpp, vocab_size_java))

maxlen_cpp = data_cpp.shape[1]
maxlen_java = data_java_out.shape[1]
print("seqlen (cpp): {:d}, (java): {:d}".format(maxlen_cpp, maxlen_java))

min_samples = min(data_cpp.shape[0], data_java_in.shape[0])
min_seq_len = min(data_cpp.shape[1], data_java_in.shape[1])
data_cpp.resize((min_samples, min_seq_len))
data_java_in.resize((min_samples, min_seq_len))
data_java_out.resize((min_samples, min_seq_len))
print("data_cpp.shape = ")
print(data_cpp.shape)
print("data_java_in.shape = ")
print(data_java_in.shape)
print("data_java_out.shape = ")
print(data_java_out.shape)

batch_size = BATCH_SIZE
dataset = tf.data.Dataset.from_tensor_slices((data_cpp, data_java_in, data_java_out))
dataset = dataset.shuffle(100)
test_size = 10000 
test_dataset = dataset.take(test_size).batch(batch_size, drop_remainder=True)
train_dataset = dataset.skip(test_size).batch(batch_size, drop_remainder=True)

# check encoder/decoder dimensions
embedding_dim = EMBEDDING_DIM
encoder_dim, decoder_dim = ENCODER_DIM, DECODER_DIM

encoder = Encoder(vocab_size_cpp+1, embedding_dim, maxlen_cpp, encoder_dim)
decoder = Decoder(vocab_size_java+1, embedding_dim, maxlen_java, decoder_dim)

optimizer = tf.keras.optimizers.Adam()
checkpoint_prefix = os.path.join(checkpoint_dir, "ckpt")
checkpoint = tf.train.Checkpoint(optimizer=optimizer,
                                 encoder=encoder,
                                 decoder=decoder)

num_epochs = NUM_EPOCHS
eval_scores = []

for e in range(num_epochs):
    encoder_state = encoder.init_state(batch_size)

    for batch, data in enumerate(train_dataset):
        encoder_in, decoder_in, decoder_out = data
        #print(encoder_in.shape, decoder_in.shape, decoder_out.shape)
        loss = train_step(
            encoder_in, decoder_in, decoder_out, encoder_state)
    
    print("Epoch: {}, Loss: {:.4f}".format(e + 1, loss.numpy()))

    if e % 10 == 0:
        checkpoint.save(file_prefix=checkpoint_prefix)
    
    predict(encoder, decoder, batch_size, cpp_code_line, data_cpp,
        java_code_line_out, word2idx_java, idx2word_java, min_samples)

checkpoint.save(file_prefix=checkpoint_prefix)
