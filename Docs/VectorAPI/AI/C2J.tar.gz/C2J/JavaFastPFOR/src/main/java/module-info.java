// Copyright (C) 2022 Intel Corporation

// SPDX-License-Identifier: Apache-2.0
module me.lemire.integercompression {
  // This is currently only for advanced users:
  // requires jdk.incubator.vector;
  exports me.lemire.integercompression;
  exports me.lemire.longcompression;
  // exports me.lemire.integercompression.vector;
}
