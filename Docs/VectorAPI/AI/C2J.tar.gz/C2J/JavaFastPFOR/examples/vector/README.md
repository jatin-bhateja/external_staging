Compile
-------
```
javac -cp <path/to/javafastpfor.jar> Example.java
```

Run
---
```
java --add-modules jdk.incubator.vector -cp <path/to/javafastpfor.jar> Example 0
```

