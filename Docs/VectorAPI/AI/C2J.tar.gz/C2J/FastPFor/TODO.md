
- Currently, users have to make educated guesses regarding compression buffer sizes. This information should be provided automatically by the library.
